package com.restaurant.enums;

public enum DISH_TYPE {
	APPETIZER, ENTREE, DESERT
}
