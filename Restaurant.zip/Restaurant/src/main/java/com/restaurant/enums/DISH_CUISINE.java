package com.restaurant.enums;

public enum DISH_CUISINE {
	INDIAN, ITALIAN, BRAZILIAN, CHINEESE
	
}
